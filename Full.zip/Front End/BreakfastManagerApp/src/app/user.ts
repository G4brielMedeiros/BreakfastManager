export class User {
  name!: string;
  cpf!: string;
  items!: string;
}
