package project.gabrielmedeiros.breakfastmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BreakfastmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BreakfastmanagerApplication.class, args);
	}
	
	

}
